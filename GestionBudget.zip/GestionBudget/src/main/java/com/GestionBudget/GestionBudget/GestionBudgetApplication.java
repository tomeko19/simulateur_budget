package com.GestionBudget.GestionBudget;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionBudgetApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionBudgetApplication.class, args);
	}

}
